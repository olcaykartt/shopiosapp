package bf.io.openshop.interfaces;

import android.view.View;

import bf.io.openshop.entities.drawerMenu.DrawerItemCategory;

public interface DrawerSubmenuRecyclerInterface {

    void onSubCategorySelected(View v, DrawerItemCategory drawerItemCategory);

}
