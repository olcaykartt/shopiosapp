package bf.io.openshop.interfaces;

import bf.io.openshop.entities.Banner;

public interface BannersRecyclerInterface {

    void onBannerSelected(Banner banner);

}
