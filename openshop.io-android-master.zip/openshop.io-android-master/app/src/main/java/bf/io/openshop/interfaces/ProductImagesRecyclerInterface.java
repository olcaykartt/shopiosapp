package bf.io.openshop.interfaces;

import android.view.View;

public interface ProductImagesRecyclerInterface {

    void onImageSelected(View v, int position);
}
